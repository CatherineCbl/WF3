<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <title>MOVIES</title>
        <link rel="stylesheet" href="/github/WF3/cabeuil_catherine_eval/exercice3/inc/css/style.css">
    </head>
    <body>
        <header>
            <div class="conteneur">
                <span>
                    <h1>MOVIES</h1>
                </span>
                <nav>
                    <?php
                        echo '<a href="exercice3_films.php?action=affichage">Tous les films</a>';
                     ?>
                </nav>
            </div>
        </header>
        <section>
            <div class="conteneur">
